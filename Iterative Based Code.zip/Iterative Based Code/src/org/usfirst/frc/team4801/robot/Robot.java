package org.usfirst.frc.team4801.robot;

import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;


	public class Robot extends IterativeRobot {
RobotDrive myRobot = new RobotDrive(0,1,2,3); 
	
Joystick wiiMote = new Joystick(0);
Joystick nimrod = new Joystick(1);
Timer timer = new Timer(); 		

Compressor comp = new Compressor(0);
DoubleSolenoid sole = new DoubleSolenoid(1,2);
Solenoid sole1 = new Solenoid(3);
 	
VictorSP mech0 = new VictorSP(4);
VictorSP mech1 = new VictorSP(6);
VictorSP mech2 = new VictorSP(5);
VictorSP mech3 = new VictorSP(7);



	@Override
	public void robotInit() {
		CameraServer.getInstance().startAutomaticCapture();
	}

	
	@Override
	public void autonomousInit() {
		comp.setClosedLoopControl(true);
		
		timer.reset();
		timer.start();
	} 

	
	
	@Override
	public void autonomousPeriodic() {
		// nico nico 
		if (timer.get() < 2.5) {
			myRobot.drive(0.6, 0.0);
		}
	    
	    }
	
	@Override
	public void teleopInit() {
		myRobot.arcadeDrive(wiiMote);

		} 
	

	/**
	 * This function is called periodically during operator control
	 */
	@Override
	public void teleopPeriodic() {
		//driveRight1.set(0.7);
		//driveRight2.set(0.7);
		
		
		myRobot.setSafetyEnabled(true);
		while (isOperatorControl() && isEnabled()) {
			myRobot.arcadeDrive(-wiiMote.getY(), -wiiMote.getX());
			Timer.delay(0.005); // wait for a motor update time
			
			
			//mech 0?	
			if(wiiMote.getRawButton(7)) {
				mech0.set(0.2);
				mech1.set(0.2);
				mech2.set(0.2);
				mech3.set(0.2);
			}
			
			//mech 0?
			if(wiiMote.getRawButton(8)) {
				mech0.set(0.4);
				mech1.set(0.4);
				mech2.set(0.4);
				mech3.set(0.4);
			}
			
			//mech 0?
			if(wiiMote.getRawButton(9)) {
				mech0.set(0.6); 	
				mech1.set(0.6);
				mech2.set(0.6);
				mech3.set(0.6);
			}

			//mech 0?
			if(wiiMote.getRawButton(2)) {
				mech0.set(0.0);
				mech1.set(0.0);
				mech2.set(0.0);
				mech3.set(0.0);
			}
			
			
			
			
			// theses commands are for the pumps
				//exampleDouble.set(DoubleSolenoid.Value.kOff);
				//exampleDouble.set(DoubleSolenoid.Value.kForward);
				//exampleDouble.set(DoubleSolenoid.Value.kReverse);
			
			//grabber close
			if(wiiMote.getRawButton(5)){
				sole.set(DoubleSolenoid.Value.kReverse);
			}
			
			//grabber open
			if(wiiMote.getRawButton(3)) {
				sole.set(DoubleSolenoid.Value.kForward);
			}
		}}
			
			
			/*
			 * 
			 */
			
		
	
	
	

	/**
	 * This function is called periodically during test mode
	 */
	@Override
	public void testPeriodic() {
		LiveWindow.run();
	}
}